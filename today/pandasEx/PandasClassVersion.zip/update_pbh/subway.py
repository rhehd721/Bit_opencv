import pandas as pd

class Subway:
    def __init__(self):
        self.times = ['06시 이전', '06 ~ 07', '07 ~ 08', '08 ~ 09', '09 ~ 10', '10 ~ 11',
                 '11 ~ 12', '12 ~ 13', '13 ~ 14', '14 ~ 15', '15 ~ 16', '16 ~ 17',
                 '17 ~ 18', '18 ~ 19', '19 ~ 20', '20 ~ 21', '21 ~ 22', '22 ~ 23', '23 ~ 24', '24시 이후']

        self.month = ['2019-02-01', '2019-03-01', '2019-04-01', '2019-05-01',
                 '2019-06-01', '2019-07-01', '2019-08-01', '2019-09-01', '2019-10-01',
                 '2019-11-01', '2019-12-01', '2020-01-01', ]

        self.week = ['월', '화', '수', '목', '금', '토', '일']

    def DataSegmentation(self):
        # 내가 사용할 데이터파일 불러오기
        df = pd.read_excel('subway.xlsx')

        station1 = input("추출할 첫번째 역이름을 입력하세요 \n ex. 강남, 신도림, 사당 ...")
        station2 = input("추출할 두번째 역이름을 입력하세요 \n ex. 강남, 신도림, 사당 ...")

        # 강남과 신도림데이터 추출두
        Data1 = df[df['역명'] == station1]
        Data2 = df[df['역명'] == station2]

        # 강남과 신도림으로 나눈 데이터 저장
        Data1.to_excel(excel_writer='data/Data1.xlsx')
        Data2.to_excel(excel_writer='data/Data2.xlsx')

        # 원하는 달에 데이터만 추출
        ChoiceMonth = int(input("추출하고 싶은 달을 입력하세요"))-1
        df = Data1[Data1['날짜'] < pd.to_datetime(self.month[ChoiceMonth])]
        df.to_excel(excel_writer='data/Data1ChoiceMonth.xlsx')
        df = Data2[Data2['날짜'] < pd.to_datetime(self.month[ChoiceMonth])]
        df.to_excel(excel_writer='data/Data2ChoiceMonth.xlsx')

        return station1, station2

    def LeastTime(self, station, Data):
        # 바구니 만들기
        RideList = []    # 시간대별 최소값을 담을 딕셔너리
        QuitList = []    # 시간대별 최소값을 담을 딕셔너리
        RideDic = {}    # 시간대별 최소값을 담을 딕셔너리
        QuitDic = {}    # 시간대별 최소값을 담을 딕셔너리

        # 승차와 하차 구별하기
        Ride = Data[Data['구분'] == '승차']
        Quit = Data[Data['구분'] == '하차']

        # 시간별 이용자 평균값 넣어주기
        for time in self.times:
            RideDic[Ride[time].mean()] = time
            QuitDic[Quit[time].mean()] = time
            RideList.append(Ride[time].mean())
            QuitList.append(Quit[time].mean())

        # 최소이용률 구하기
        RideList.sort()
        QuitList.sort()

        # 이용객이 가장 적은 시간대 print
        print(station, "에서 승차가 제일 적은 시간은 : ", RideDic[RideList[0]])
        print(station, "에서 하차가 제일 적은 시간은 : ", QuitDic[QuitList[0]])

    def LeastTimeDay(self, station, Data):

        # 바구니
        RideMeanList = []    # 시간대별 최소값을 담을 딕셔너리
        QuitMeanList = []    # 시간대별 최소값을 담을 딕셔너리

        # 7 ~ 9시 줄이기
        for i in range(0, 2):
            Data = Data.drop(self.times[i], axis=1)
        for i in range(4, len(self.times)):
            Data = Data.drop(self.times[i], axis=1)

        # 월별로 나누기
        for i in range(0, len(self.month)):
            # 강남 승차
            max = Data[ Data['날짜'] < pd.to_datetime(self.month[i])]    # 달별로 추리기
            max = max[max['구분'] == '승차']    # 승하차 구분
            max = max['합 계'].max()  # 승차에서 가장 많은거 추출
            maxWeek = Data[ Data['날짜'] < pd.to_datetime(self.month[i])]    # 달별로 다시 추리기
            maxWeek = maxWeek[maxWeek['합 계'] == max]    # 위에서 구한 max에 해방하는 구간 구하기
            maxWeek = pd.to_datetime(str(maxWeek['날짜'].min())).weekday()    # 해당구간의 datetime이용하여 요일구하기
            RideMeanList.append(maxWeek)

            # 강남 하차
            max = Data[ Data['날짜'] < pd.to_datetime(self.month[i])]
            max = max[max['구분'] == '하차']
            max = max['합 계'].max()
            maxWeek = Data[Data['날짜'] < pd.to_datetime(self.month[i])]
            maxWeek = maxWeek[maxWeek['합 계'] == max]
            maxWeek = pd.to_datetime(str(maxWeek['날짜'].min())).weekday()
            QuitMeanList.append(maxWeek)


        for i in range(0, len(self.month)):
            print(station, i+1,'월 7 ~ 9시 가장 많은 승차 요일 : ', self.week[int(RideMeanList[i])])
            print(station, i+1, '월 7 ~ 9시  가장 많은 하차 요일 : ', self.week[int(QuitMeanList[i])])

    def LeastTimeMonth(self, station, Data):

        # 7 ~ 9시 줄이기
        for i in range(0,2):
            Data = Data.drop(self.times[i], axis=1)
        for i in range(4,len(self.times)):
            Data = Data.drop(self.times[i], axis=1)

        Sum = {}    # 달마다 이용객을 담을 딕셔너리
        SumList = []    # 달마다 이용객을 담을 리스트

        # 월별로 나누기
        for i in range(0, len(self.month)):
            sum = Data[ Data['날짜'] < pd.to_datetime(self.month[i])]
            sum = sum['합 계'].sum()
            Sum[sum] = i + 1
            SumList.append(sum)

        SumList.reverse()

        print(station, "에서 이용자가 제일 많은 달은 : ", Sum[SumList[0]], '월')
