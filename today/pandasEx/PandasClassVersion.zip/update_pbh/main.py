# 1. 내가 이용하는 지하철 역(승차역, 하차역)의 정보를 골라서 데이터프레임으로 저장
# 2. 1번의 데이터에서 1월의 데이터만 선택
# 3. 승차역과 하차역에서 가장 이용객이 적은 시간은?

# 4. 2번의 데이터에서 월별 통계 데이터를 확인 (7~9시 사이의 승차역과 하차역의 평균치) 어느 요일이 이용객이 가장 많고 적은가?
# 5. 1~12월까지중 이용객이 가장 많은달은? (7~9시 사이)

import pandas as pd
import datetime

from subway import Subway

# class 받아오기
Sub = Subway()

# 원하는 역과 원하는 달에 입력된 데이터 추출하기
station1, station2 = Sub.DataSegmentation()

# 저장한 데이터 읽어오기
Data1 = pd.read_excel('data/Data1ChoiceMonth.xlsx')
Data2 = pd.read_excel('data/Data2ChoiceMonth.xlsx')

# 최소시간 구하기
Sub.LeastTime(station1, Data1)
Sub.LeastTime(station2, Data2)

# 달을 나누지 않은 데이터 불러오기
Data1 = pd.read_excel('data/Data1.xlsx')
Data2 = pd.read_excel('data/Data2.xlsx')

# 요일 이용객 구하기
Sub.LeastTimeDay(station1, Data1)
Sub.LeastTimeDay(station2, Data2)

# 1 ~ 12 최대인 날

Sub.LeastTimeMonth(station1, Data1)
Sub.LeastTimeMonth(station2, Data2)
